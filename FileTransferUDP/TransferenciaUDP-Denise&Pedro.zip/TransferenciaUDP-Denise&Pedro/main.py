from FileTransferUDP import FileTransferUDP

fileTransfer = FileTransferUDP()
fileTransfer.begin()
