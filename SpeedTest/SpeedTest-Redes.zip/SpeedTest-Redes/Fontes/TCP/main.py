from SpeedTest import SpeedTest

speedTest = SpeedTest()
speedTest.begin()
