from SpeedTest import SpeedTest

fileTransfer = SpeedTest()
fileTransfer.begin()
